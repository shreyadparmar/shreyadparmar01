let secretNumber;
let attempts = 0;
let maxAttempts = 10;

document.addEventListener('DOMContentLoaded', () => {
    startGame();

    document.getElementById('submitGuess').addEventListener('click', checkGuess);
    document.getElementById('restartButton').addEventListener('click', startGame);
});

function startGame() {
    secretNumber = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    document.getElementById('feedback').textContent = '';
    document.getElementById('attempts').textContent = `Attempts remaining: ${maxAttempts}`;
    document.getElementById('restartButton').style.display = 'none';
    document.getElementById('guessInput').value = '';
}

function checkGuess() {
    const guess = parseInt(document.getElementById('guessInput').value);
    if (isNaN(guess) || guess < 1 || guess > 100) {
        alert('Please enter a valid number between 1 and 100.');
        return;
    }

    attempts++;
    if (guess === 50) {
        document.getElementById('feedback').textContent = `Congratulations! You guessed the number in ${attempts} attempts.`;
        document.getElementById('feedback').style.color = 'green';
        endGame();
    } else if (guess < 50) {
        document.getElementById('feedback').textContent = 'Too low! Try again.';
        document.getElementById('feedback').style.color = 'red';
    } else {
        document.getElementById('feedback').textContent = 'Too high! Try again.';
        document.getElementById('feedback').style.color = 'red';
    }

    if (attempts >= maxAttempts) {
        document.getElementById('feedback').textContent = `Sorry, you've used all your attempts. The number was ${secretNumber}.`;
        document.getElementById('feedback').style.color = 'red';
        endGame();
    }

    document.getElementById('attempts').textContent = `Attempts remaining: ${maxAttempts - attempts}`;
}

function endGame() {
    document.getElementById('submitGuess').disabled = true;
    document.getElementById('restartButton').style.display = 'block';
}

